function f1(arg1, arg2) {}

const f1 = (arg1, arg2) => {};

const onlyOneArg = (arg1) => {};

// const onlyOneLine = (arg1, arg2) => {
//   return arg1 + arg2;
// };

const onlyOneLine = (arg1, arg2) => arg1 + arg2;
