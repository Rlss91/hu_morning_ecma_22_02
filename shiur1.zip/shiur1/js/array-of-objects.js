let arr = [
  {
    name: "kenny",
    age: 7,
  },
  {
    name: "bob",
    age: 30,
  },
];

//how to get the name of the first element of arr
console.log(arr[0].name);
